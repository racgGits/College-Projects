package com.example.centralisedmedicaldatamanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class view_info_page extends AppCompatActivity {

    Button all_appointments,prev_appointments;
    EditText patient_id3,doctor_id3;
    static String patid,docid;
    private List<String> namelist = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_info_page);

        all_appointments=findViewById(R.id.all_appointments);
        prev_appointments=findViewById(R.id.prev_appointments);
        patient_id3=findViewById(R.id.patient_id3);
        doctor_id3=findViewById(R.id.doctor_id3);
        String patient = patient_id3.getText().toString();
        /*all_appointments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> a = new ArrayList<>();
                ArrayAdapter adapter = new ArrayAdapter<String>(view_info_page.this,R.layout.appointments_view,a);
                appointments.setAdapter(adapter);
                FirebaseDatabase.getInstance().getReference().child("John123").child("Doc125").child("01").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()){
                            a.clear();
                            for(DataSnapshot snapshot1:snapshot.getChildren()){
                                pat_apt_details i = snapshot1.getValue(pat_apt_details.class);
                                String t = i.getPatient_id()+":"+i.getDoctor_id()+":"+i.getAppointment_no()+":"+i.getAppointment_type()+":"+i.getProblem_diagnosed()+":"+i.getSuggested_medicines()+":"+i.getSuggested_tests()+":"+i.getCuration_period()+":"+i.getFeedback();
                                a.add(t);

                            }
                        adapter.notifyDataSetChanged();} }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });*/
//        all_appointments.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                String patient = patient_id3.getText().toString();
//                FirebaseFirestore.getInstance().collection("Pat123").addSnapshotListener(new EventListener<QuerySnapshot>() {
//                    @Override
//                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
//                        namelist.clear();
//                        for (DocumentSnapshot s:value){
//                            namelist.add("Patient ID : "+s.getString("PatientId") + "\n" +"Doctor ID : "  + s.getString("DoctorId") +"\n"+ "Appointment Number : "+s.getString("AppointmentNo")+"\n"+"Appointment Type : "+ s.getString("AppointmentType")+"\n"+"Problem Diagnosed : " +s.getString("Problem Diagnosed")+"\n"+"Suggested Medicines : " +s.getString("Suggested Medicines")+"\n"+"Suggested Tests : " +s.getString("Suggested Tests")+"\n"+ "Curation Period : "+s.getString("Curation Period")+"\n"+"Feedback of Previous Appointment : " +s.getString("Feedback of previous appointment"));
//                        }
//                        ArrayAdapter adapter = new ArrayAdapter<String>(view_info_page.this,android.R.layout.simple_selectable_list_item,namelist);
//                        adapter.notifyDataSetChanged();
//                        appointments.setAdapter(adapter);
//                    }
//                });
//            }
//        });
        all_appointments.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                patid = patient_id3.getText().toString();

                startActivity(new Intent(view_info_page.this,recycler_view_final2.class));
            }
        });
        prev_appointments.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                patid = patient_id3.getText().toString();
                docid = doctor_id3.getText().toString();
                startActivity(new Intent(view_info_page.this,recycler_view_final.class));
            }
        });

    }
}