package com.example.centralisedmedicaldatamanagementsystem;

import static com.example.centralisedmedicaldatamanagementsystem.view_info_page.docid;
import static com.example.centralisedmedicaldatamanagementsystem.view_info_page.patid;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class recycler_view_final2 extends AppCompatActivity {

    private RecyclerView mfirestoreList;
    private FirebaseFirestore firebaseFirestore;
    private FirestoreRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view_final2);

        firebaseFirestore=FirebaseFirestore.getInstance();
        mfirestoreList=findViewById(R.id.firestore_list2);
        Query query = firebaseFirestore.collection(patid).orderBy("AppointmentNo", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<Firestore_Model> options = new FirestoreRecyclerOptions.Builder<Firestore_Model>()
                .setQuery(query,Firestore_Model.class)
                .build();
        adapter = new FirestoreRecyclerAdapter<Firestore_Model, recycler_view_final2.Pat123ViewHolder>(options) {
            @NonNull
            @Override
            public recycler_view_final2.Pat123ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_single,parent,false);
                return new recycler_view_final2.Pat123ViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull recycler_view_final2.Pat123ViewHolder holder, int position, @NonNull Firestore_Model model) {
                holder.list_pat_id.setText(model.getPatientId());
                holder.list_doc_id.setText(model.getDoctorId());
                holder.list_appointment_no.setText(model.getAppointmentNo());
                holder.list_appointment_type.setText(model.getAppointmentType());
                holder.list_problem_diagnosed.setText(model.getProblems_Diagnosed());
                holder.list_suggested_medicines.setText(model.getSuggested_Medicines());
                holder.list_suggested_tests.setText(model.getSuggested_Tests());
                holder.list_curation_period.setText(model.getCuration_Period());
                holder.list_feed_back.setText(model.getFeedback_of_previous_appointment());
            }
        };
        mfirestoreList.setHasFixedSize(true);
        mfirestoreList.setLayoutManager(new LinearLayoutManager(this));
        mfirestoreList.setAdapter(adapter);
    }

    private class Pat123ViewHolder extends RecyclerView.ViewHolder {
        private TextView list_pat_id,list_doc_id,list_appointment_no,list_appointment_type,list_problem_diagnosed,list_suggested_medicines,list_suggested_tests,list_curation_period,list_feed_back;
        public Pat123ViewHolder(@NonNull View itemView) {
            super(itemView);
            list_pat_id=itemView.findViewById(R.id.list_pat_id);
            list_doc_id=itemView.findViewById(R.id.list_doc_id);
            list_appointment_no=itemView.findViewById(R.id.list_appointment_no);
            list_appointment_type=itemView.findViewById(R.id.list_appointment_type);
            list_problem_diagnosed=itemView.findViewById(R.id.list_problem_diagnosed);
            list_suggested_medicines=itemView.findViewById(R.id.list_suggested_medicines);
            list_suggested_tests=itemView.findViewById(R.id.list_suggested_tests);
            list_curation_period=itemView.findViewById(R.id.list_expected_curation_period);
            list_feed_back=itemView.findViewById(R.id.list_feedback);

        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.startListening();
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }
}