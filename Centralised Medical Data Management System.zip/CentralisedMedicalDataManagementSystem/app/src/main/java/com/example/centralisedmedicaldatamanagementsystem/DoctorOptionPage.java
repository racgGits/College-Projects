package com.example.centralisedmedicaldatamanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DoctorOptionPage extends AppCompatActivity {
    Button newappointment,history;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_option_page);
        newappointment = findViewById(R.id.addAppointment);
        history = findViewById(R.id.viewHistory);
        newappointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DoctorOptionPage.this,AppointmentDetails.class));
            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DoctorOptionPage.this,view_info_page.class));
            }
        });
    }
}