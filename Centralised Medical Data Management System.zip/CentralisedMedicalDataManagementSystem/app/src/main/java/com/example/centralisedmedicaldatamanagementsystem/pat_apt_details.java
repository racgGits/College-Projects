package com.example.centralisedmedicaldatamanagementsystem;

public class pat_apt_details {
    public String patient_id,doctor_id,appointment_no,appointment_type,problem_diagnosed,suggested_medicines,suggested_tests,curation_period,feedback;
    public pat_apt_details(){

    }
//    public pat_apt_details(String patient_id,String doctor_id,String appointment_no,String appointment_type,String problem_diagnosed,String suggested_medicines,String suggested_tests,String curation_period,String feedback){
//        this.patient_id=patient_id;
//        this.doctor_id=doctor_id;
//        this.appointment_no=appointment_no;
//        this.appointment_type=appointment_type;
//        this.problem_diagnosed=problem_diagnosed;
//        this.suggested_medicines=suggested_medicines;
//        this.suggested_tests=suggested_tests;
//        this.curation_period=curation_period;
//        this.feedback=feedback;
//    }

    public String getPatient_id() {
        return patient_id;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public String getAppointment_no() {
        return appointment_no;
    }

//    public String getAppointment_type() {
//        return appointment_type;
//    }
//
//    public String getProblem_diagnosed() {
//        return problem_diagnosed;
//    }
//
//    public String getSuggested_medicines() {
//        return suggested_medicines;
//    }
//
//    public String getSuggested_tests() {
//        return suggested_tests;
//    }
//
//    public String getCuration_period() {
//        return curation_period;
//    }
//
//    public String getFeedback() {
//        return feedback;
//    }
//
//    public void setPatient_id(String patient_id) {
//        this.patient_id = patient_id;
//    }
//
//    public void setDoctor_id(String doctor_id) {
//        this.doctor_id = doctor_id;
//    }
//
//    public void setAppointment_no(String appointment_no) {
//        this.appointment_no = appointment_no;
//    }
//
//    public void setAppointment_type(String appointment_type) {
//        this.appointment_type = appointment_type;
//    }
//
//    public void setProblem_diagnosed(String problem_diagnosed) {
//        this.problem_diagnosed = problem_diagnosed;
//    }
//
//    public void setSuggested_medicines(String suggested_medicines) {
//        this.suggested_medicines = suggested_medicines;
//    }
//
//    public void setSuggested_tests(String suggested_tests) {
//        this.suggested_tests = suggested_tests;
//    }
//
//    public void setCuration_period(String curation_period) {
//        this.curation_period = curation_period;
//    }
//
//    public void setFeedback(String feedback) {
//        this.feedback = feedback;
//    }
}

