package com.example.centralisedmedicaldatamanagementsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AppointmentDetails extends AppCompatActivity {
    EditText patient_id,doctor_id,appointment_no,appointment_type,problem_diagnosed,suggested_medicines,suggested_tests,curation_period,feedback;
    Button add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_details);
        patient_id = findViewById(R.id.patient_id2);
        doctor_id = findViewById(R.id.doctor_id);
//        age = findViewById(R.id.age);
//        gender = findViewById(R.id.gender);
        appointment_no = findViewById(R.id.appointment_no);
        appointment_type = findViewById(R.id.appointment_type);
        problem_diagnosed = findViewById(R.id.problem_diagnosed);
        suggested_medicines = findViewById(R.id.suggested_medicines);
        suggested_tests  = findViewById(R.id.suggested_tests);
        curation_period = findViewById(R.id.curation_period);
        feedback = findViewById(R.id.feedback);
        add = findViewById(R.id.add_info);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String patientID,doctorID,appointmentNo;
                patientID = patient_id.getText().toString();
                doctorID = doctor_id.getText().toString();
                appointmentNo = appointment_no.getText().toString();
                Map<String,String> m= new HashMap<>();
                m.put("PatientId","PatientId : "+patient_id.getText().toString());
                m.put("DoctorId","DoctorId : "+doctor_id.getText().toString());
//                m.put("Age",age.getText().toString());
//                m.put("Gender",gender.getText().toString());
                m.put("AppointmentNo","AppointmentNo : "+appointment_no.getText().toString());
                m.put("AppointmentType","AppointmentType : "+appointment_type.getText().toString());
                m.put("Problems_Diagnosed","Problems Diagnosed : "+problem_diagnosed.getText().toString());
                m.put("Suggested_Medicines","Suggested Medicines : "+suggested_medicines.getText().toString());
                m.put("Suggested_Tests","Suggested Tests : "+suggested_tests.getText().toString());
                m.put("Curation_Period",("Curation Period : "+curation_period.getText().toString()));
                m.put("Feedback_of_previous_appointment","Feedback of Previous Appointment : " +feedback.getText().toString());
                FirebaseFirestore.getInstance().collection(patientID).add(m).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        Toast.makeText(getApplicationContext(), "DATA INSERTED SUCCESSFULLY!", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}