package com.example.centralisedmedicaldatamanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class PatientPage extends AppCompatActivity {

    EditText name,id;
    Button loginbtn2;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_page);
        name = (EditText) findViewById(R.id.petname);
        id = (EditText) findViewById(R.id.petpassword);
        loginbtn2 =(Button) findViewById(R.id.viewHistory);
        auth=FirebaseAuth.getInstance();
        loginbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String docid = name.getText().toString();
                String docpwd = id.getText().toString();
                //String patid = patient_id.getText().toString();
                if (TextUtils.isEmpty(docid) ){
                    Log.d("inputfield","Field1");
                    Toast.makeText(PatientPage.this, "ALL FIELDS ARE MANDATORY", Toast.LENGTH_LONG).show();
                }
                if (TextUtils.isEmpty(docpwd) ){
                    Log.d("inputfield","Field2");
                    Toast.makeText(PatientPage.this, "ALL FIELDS ARE MANDATORY", Toast.LENGTH_LONG).show();
                }
//                if (TextUtils.isEmpty(patid) ){
//                    Log.d("inputfield","Field3");
//                    Toast.makeText(DoctorLoginPage.this, "ALL FIELDS ARE MANDATORY", Toast.LENGTH_LONG).show();
//                }
                else{
                    login(docid,docpwd);
                }
            }
        }
        );
    } private void login (String loginid , String pwd){
        auth.signInWithEmailAndPassword(loginid,pwd).addOnSuccessListener(PatientPage.this, new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Toast.makeText(PatientPage.this, "LOGIN SUCCESSFUL", Toast.LENGTH_LONG).show();
                startActivity(new Intent(PatientPage.this,view_info_page.class));
            }
        });
    }
}