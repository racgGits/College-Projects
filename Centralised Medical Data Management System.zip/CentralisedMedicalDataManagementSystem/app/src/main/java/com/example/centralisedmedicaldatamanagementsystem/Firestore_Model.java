package com.example.centralisedmedicaldatamanagementsystem;

public class Firestore_Model {
    private String AppointmentNo,AppointmentType,Curation_Period,DoctorId,Feedback_of_previous_appointment,PatientId,Problems_Diagnosed,Suggested_Medicines,Suggested_Tests;
    private Firestore_Model(){}
    private Firestore_Model(String AppointmentNo,String AppointmentType,String Curation_Period,String DoctorId,String Feedback_of_previous_appointment,String PatientId,String Problems_Diagnosed,String Suggested_Medicines,String Suggested_Tests){
        this.AppointmentNo=AppointmentNo;
        this.AppointmentType=AppointmentType;
        this.Curation_Period=Curation_Period;
        this.Suggested_Medicines=Suggested_Medicines;
        this.Suggested_Tests=Suggested_Tests;
        this.DoctorId=DoctorId;
        this.Feedback_of_previous_appointment=Feedback_of_previous_appointment;
        this.PatientId=PatientId;
        this.Problems_Diagnosed=Problems_Diagnosed;

    }


    public String getAppointmentNo() {
        return AppointmentNo;
    }

    public void setAppointmentNo(String appointmentNo) {
        AppointmentNo = appointmentNo;
    }

    public String getAppointmentType() {
        return AppointmentType;
    }

    public void setAppointmentType(String appointmentType) {
        AppointmentType = appointmentType;
    }

    public String getCuration_Period() {
        return Curation_Period;
    }

    public void setCuration_Period(String curation_Period) {
        Curation_Period = curation_Period;
    }

    public String getDoctorId() {
        return DoctorId;
    }

    public void setDoctorId(String doctorId) {
        DoctorId = doctorId;
    }

    public String getFeedback_of_previous_appointment() {
        return Feedback_of_previous_appointment;
    }

    public void setFeedback_of_previous_appointment(String feedback_of_previous_appointment) {
        Feedback_of_previous_appointment = feedback_of_previous_appointment;
    }

    public String getPatientId() {
        return PatientId;
    }

    public void setPatientId(String patientId) {
        PatientId = patientId;
    }

    public String getProblems_Diagnosed() {
        return Problems_Diagnosed;
    }

    public void setProblems_Diagnosed(String problems_Diagnosed) {
        Problems_Diagnosed = problems_Diagnosed;
    }

    public String getSuggested_Medicines() {
        return Suggested_Medicines;
    }

    public void setSuggested_Medicines(String suggested_Medicines) {
        Suggested_Medicines = suggested_Medicines;
    }

    public String getSuggested_Tests() {
        return Suggested_Tests;
    }

    public void setSuggested_Tests(String suggested_Tests) {
        Suggested_Tests = suggested_Tests;
    }
}
